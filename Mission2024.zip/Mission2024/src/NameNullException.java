class NameNullException extends Exception {
    public NameNullException(String message) {
        super(message);
    }
}
