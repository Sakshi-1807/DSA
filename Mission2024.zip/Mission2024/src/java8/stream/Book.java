package java8.stream;
import java.sql.SQLOutput;
import java.util.*;
import java.util.stream.Collectors;

public class Book {
    private String title;
    private String author;
    private int releaseYear;
    private int soldCopies;
    public Book(String title, String author, int releaseYear, int soldCopies) {
        this.title = title;
        this.author = author;
        this.releaseYear = releaseYear;
        this.soldCopies = soldCopies;
    }

    // Constructor, getters and setters


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public void setReleaseYear(int releaseYear) {
        this.releaseYear = releaseYear;
    }

    public int getSoldCopies() {
        return soldCopies;
    }

    public void setSoldCopies(int soldCopies) {
        this.soldCopies = soldCopies;
    }
    static List<Book> books = Arrays.asList(
            new Book("The Fellowship of the Ring", "J.R.R. Tolkien", 1954, 30),
            new Book("The Hobbit", "J.R.R. Tolkien", 1937, 40),
            new Book("Animal Farm", "George Orwell", 1945, 32),
            new Book("Nineteen Eighty-Four", "George Orwell", 1949, 50),
            new Book("Nineteen Eighty-Four", "George Orwell", 1949, 38)
    );

    public static void main(String[] args) {
      books.stream().filter(book -> book.getReleaseYear()>1950).map(Book::getTitle).collect(Collectors.toSet());



        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        int sum = numbers.stream()
                .filter(n -> n % 2 == 0) // Filter out even numbers
                .mapToInt(n -> n * 2)    // Double each number
                .sum();                  // Sum them up
        System.out.println("Sum of doubled even numbers: " + sum);

    }
}

