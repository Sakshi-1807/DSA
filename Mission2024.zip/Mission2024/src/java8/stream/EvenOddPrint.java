package java8.stream;


import java.util.*;
import java.util.stream.*;

public class EvenOddPrint {
    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(10, 2, 4, 6, 1, 11, 43, 67);
        //list.stream().filter(a -> a > 10).collect(Collectors.toList()).forEach(System.out::println);
        int a[] = {1,4,6,33,41,2,8};
        String name[] = {"sakshi","jain"};
        Stream<String> stream = Stream.of(name);
        Stream<Integer> stream1 = Arrays.stream(a).boxed();
        stream1.forEach(e->
        {System.out.print(e +",");
        }
        );

    }
}
