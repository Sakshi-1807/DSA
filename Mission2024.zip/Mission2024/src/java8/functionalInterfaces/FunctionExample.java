package java8.functionalInterfaces;

import java.util.function.Function;

public class FunctionExample {
    public static void main(String[] args) {
        // Function to square a number
        Function<Integer, Integer> square = n -> n * n;

        // Applying the function to a number
        int result = square.apply(5);
        System.out.println("Square of 5: " + result);
    }
}
