package java8.functionalInterfaces;

@FunctionalInterface
interface Printable{
    public void print();

    public static void print3D() {
        System.out.println("3D Printing");
    }
}
 abstract class FunctionalInterfaceLearning {
    public static void main(String[] args) {
        // Implementing functional interface using lambda
        Printable p = ()->System.out.println("Printing...");
        p.print();
        Printable.print3D();
    }
}