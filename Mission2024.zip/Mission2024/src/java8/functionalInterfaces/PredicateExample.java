package java8.functionalInterfaces;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class PredicateExample {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);

        // Predicate to filter even numbers
        Predicate<Integer> isEven = n -> n % 2 == 0;

        // Filtering even numbers
        System.out.println("Even numbers:");
        numbers.stream()
                .filter(isEven)
                .forEach(System.out::println);
    }
}
