package java8.functionalInterfaces;
@FunctionalInterface
interface MyInterface1 {
    // Abstract method
    void abstractMethod();

    // Default method
    default void defaultMethod() {
        System.out.println("Default method in interface");
    }

    // Static method
    static void staticMethod() {
        System.out.println("Static method in interface");
    }
}
@FunctionalInterface
interface MyInterface2 {
    // Abstract method
    void abstractMethod();
}

class Myclass implements MyInterface2{
    @Override
    public void abstractMethod() {
        System.out.println("Implementation of abstract method using class ref");
    }
}

public class FunctionalInterfaceMethods {
    public static void main(String[] args) {
//(there are two ways to implement abstract method below)


        // Method 1- using lambda expression to implement MyInterface
        MyInterface1 obj = () -> System.out.println("Implementation of abstract method using lambda");
        MyInterface1 obj2 = () -> System.out.println("Implementation of abstract method using lambda in 2 object");


//Method 2-  Implementing abstract method
        Myclass myclass = new Myclass();

        // Execution of methods
        obj.abstractMethod();
        obj2.abstractMethod();
        myclass.abstractMethod();// Abstract method implementation
        obj.defaultMethod();    // Default method from interface
        MyInterface1.staticMethod(); // Static method from interface
    }
}

