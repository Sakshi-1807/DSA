package java8.functionalInterfaces;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class ConsumerExample {
    public static void main(String[] args) {
        List<String> names = Arrays.asList("John", "Alice", "Bob");

        // Consumer to print each name
        Consumer<String> printName = name -> System.out.println("Hello, " + name);

        // Printing each name
        System.out.println("Greetings:");
        names.forEach(printName);
    }
}
