package interview;

import java.util.Stack;

//write an sorting algorithum to sort a stack using an extra empty stack only.
//        [1,9,7]->[1,7,9]
public class SortStack {
    public static void main(String[] args) {
        Stack<Integer> input = new Stack<>();
        input.push(1);
        input.push(9);
        input.push(7);

        sortStack(input);
        System.out.println(input);
    }

    private static void sortStack(Stack<Integer> input) {
    Stack<Integer>  tempStack = new Stack<>();

    while(!input.isEmpty()){
        int current = input.pop();
         while(!tempStack.isEmpty() &&  tempStack.peek()< current){
             input.push(tempStack.pop());
         }
         tempStack.push(current);
    }
    while(!tempStack.isEmpty()){
        input.push(tempStack.pop());
        }
    }


}
