package interview;

import java.util.Arrays;

//array having duplicate and random integers {5,
    public class TwoPairSum {
    public static void main(String[] args) {
        int[] arr = {2,2,4,3,6,1,7,11};
        int target = 5;
        //output: 4,1 or 3,2

        Arrays.sort(arr);
        findPairSum(arr,target);
    }

    private static void findPairSum(int[] arr, int target) {
        int n = arr.length;
        //compare mid element
        int mid  = arr[n/2];
        int left , right;
        if(arr[mid] == target)
            return;
        else if(arr[mid]  > target){
            right = mid-1;
            left = 0;
        }else{
            left = mid+1;
            right = n-1;
        }
    }
}
