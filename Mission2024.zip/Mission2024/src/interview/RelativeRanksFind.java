package interview;


import java.util.*;
public class RelativeRanksFind {
    public static String[] findRelativeRanks(int[] scores) {
        PriorityQueue<Integer> heap = new PriorityQueue<>((a,b)->Integer.compare(scores[b],scores[a]));
        for(int i=0;i<scores.length;i++){
            heap.add(i);
        }
        String[] result = new String[scores.length];
        while(!heap.isEmpty()){
            String rank;
            switch(scores.length - heap.size()){
                case 0:
                    rank = "Gold medal";
                    break;
                case 1:
                    rank = "Silver medal";
                    break;
                case 2:
                    rank = "Bronze medal";
                    break;
                default:
                    rank = String.valueOf(scores.length- heap.size() +1);
                    break;
            }
            int i = heap.poll();
            result[i] = rank;
        }
        return result;
    }

    public static void main(String[] args) {
        int[] ar = {10,3,8,9,4};
        String[] result = findRelativeRanks(ar);
        System.out.println(Arrays.toString(result));
    }
}
