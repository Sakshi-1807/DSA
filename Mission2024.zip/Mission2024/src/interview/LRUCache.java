package interview;

import java.util.*;

//implementing generic lru cache class with key and value

public class LRUCache<K,V> {

    private final int capacity;
    private int size;
    private final HashMap<K, Node<K,V>> cache;
    private final DoublyLinkedList<K,V> dll;

    public LRUCache(int capacity) {
        this.capacity = capacity;
        this.size = 0;
        this.cache = new HashMap<>();
        this.dll = new DoublyLinkedList<>();
    }

    public CacheResult<V> get(K key) {
        Node<K,V> node = cache.get(key);
        if (node == null) {
            return new CacheResult<>(false, null);
        }
        dll.moveToHead(node);
        return new CacheResult<>(true,node.value);
    }
    public void put(K key, V value){
        Node<K,V> node = cache.get(key);
        if(node == null){
            Node<K,V> newNode = new Node<>(key, value);
            cache.put(key, newNode);
            dll.addNode(newNode);
            size++;
        } else {
            node.value = value; // Update the value of the existing node
            dll.moveToHead(node);
        }
        if(size > capacity){
            Node<K,V> tail = dll.popTail();
            cache.remove(tail.key);
            size--;
        }
    }

    //class will store the cache result data and pass when required:
//It encapsulates the result of get operation indicating where the key was found and the value associate to it.
    public class CacheResult<V> {
        private V value;
        private boolean found;

        public CacheResult(boolean found, V value) {
            this.found = found;
            this.value = value;
        }

        public boolean isFound() {
            return found;
        }

        //generic type
        public V getValue() {
            return value;
        }
    }
    class Node<K,V>{
        K key;
        V value;
        Node<K,V> prev;
        Node<K,V> next;

        public Node(K key, V value){
            this.key = key;
            this.value=value;
        }
    }

    //creating generic doubly linkedlist
    class DoublyLinkedList<K,V> {
        private final  Node<K,V> head;
        private final  Node<K,V> tail;
        public DoublyLinkedList(){
            head = new Node<>(null,null);
            tail =new Node<>(null,null);
            head.next = tail;
            tail.prev =head;
        }
        //add the new node just right after the head node
        public void addNode(Node<K,V> node){
            node.next =head.next;
            node.prev= head;
            head.next.prev = node;
            head.next = node;
        }
        // remove the given node item out
        public void removeNode(Node<K,V> node){
            node.prev.next = node.next;
            node.next.prev = node.prev;
        }
        //if node is there in list and again appear then moving it to first position
        public void moveToHead(Node<K,V> node){
            removeNode(node);
            addNode(node);
        }
        //in case size we need to decrease then removing the node from the last which //store the last recently used data
        public Node<K,V> popTail(){
            Node<K,V> result = tail.prev;
            removeNode(result);
            return  result;
        }

    }

    //Adding main method for you to check if it runs:
    public static void main(String[] args) {
        LRUCache<String,Integer> cache = new LRUCache<>(3);
        cache.put("key1",1);
        cache.put("key2",2);
        cache.put("key3",3);
        //accessing some element
        System.out.println(cache.get("key1").getValue());
        System.out.println(cache.get("key2").getValue());
        //lets add one more now
        cache.put("key4",4);

    }
}





