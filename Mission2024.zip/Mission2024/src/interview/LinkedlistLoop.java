package interview;


public class LinkedlistLoop {
    public static void main(String[] args) {
        Node head = new Node(3);
        Node node2 = new Node(2);
        Node node1 = new Node(1);
        Node node0 = new Node(0);

        head.next = node2;
        node2.next = node1;
        node1.next = node0;
        node0.next = node2;
        LinkedlistLoop sol = new LinkedlistLoop();
        Node start

    }
    public static class Node{
        int val;
        Node next;
        Node(int val){
            this.val = val;
            this.next = null;
        }
    }

    public Node detectCycle(Node head){
        if(head ==null ||head.next == null){
            return null;
        }
        Node slow=head, fast = head;
        boolean isLoop =false;

        while(fast!=null && fast.next ==null){
            slow= slow.next;
            fast = fast.next.next;
            if(slow==fast){
                isLoop =true;
                break;
            }
        }
        if(!isLoop){
            return null;
        }
        slow =head;
        while(slow!=fast){
            slow=slow.next;
            fast = fast.next;
        }
        return slow;
    }
}
