package interview;

import java.util.*;

public class RelativeRank {

    static class ScoreIndex {
        int score;
        int index;

        ScoreIndex(int index, int score) {
            this.score = score;
            this.index = index;
        }
    }

    public static String[] findRelativeRanks(int[] score) {
        int n = score.length;
        ScoreIndex[] scoreIndices = new ScoreIndex[n];
        //populate the index with its values
        for (int i = 0; i < n; i++) {
            scoreIndices[i] = new ScoreIndex(score[i], i);
        }
        //sorted array based on values
        Arrays.sort(scoreIndices, new Comparator<ScoreIndex>() {
            @Override
            public int compare(ScoreIndex a, ScoreIndex b) {
                return Integer.compare(b.score, a.score);
            }
        });
        String[] result = new String[n];
        int rank = 1;
        //assigning ranks based on sorted array
        for (int i = 0; i < n; i++) {
            if (i > 0 && scoreIndices[i].score != scoreIndices[i - 1].score) {
                rank = i + 1;
            }
            result[scoreIndices[i].index] = String.valueOf(rank);
        }
        return result;

    }


    public static void main(String[] args) {
        int[] ar = {5, 4, 3, 2, 1};
        String[] result = findRelativeRanks(ar);
        System.out.println(Arrays.toString(result));
    }
}
