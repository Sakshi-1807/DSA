package interview;

import java.util.*;

public class ShortestPath {
    public static Map<String, Map<String,Integer>> graph;

    public static List<Integer> shortestPath(Map<String, Map<String,Integer>> graph, String start, String end){
        Map<String, Integer> distance = new HashMap<>();
        Map<String, Integer> previous = new HashMap<>();
        PriorityQueue<String> queue = new PriorityQueue<>(Comparator.comparing(distance::get));

        for(String vertex:graph.keySet()){
            if(vertex.equals(start)){
                distance.put(vertex,0);
            }else{
                distance.put(vertex, Integer.MAX_VALUE);
            }
            queue.add(vertex);
        }
        //applying dijikstra
        while(!queue.isEmpty()){
            String current = queue.poll();
            //end point
            if(current.equals(end)){
                break;
            }
            //no more connection trhere
            if(distance.get(current)==Integer.MAX_VALUE){
                break;
            }
            //update distance
            for(Map.Entry<String, Integer> neighbor :graph.get(current).entrySet()){
                int alt = distance.get(current)+neighbor.getValue();
                if(alt<distance.get(neighbor.getKey())){
                    distance.put(neighbor.getKey(),alt);
                    previous.put(neighbor.getKey(), distance.get(current));
                    queue.remove(neighbor.getKey());
                    queue.add(neighbor.getKey());
                }
            }
        }
        //based on previous updating paths
        List<Integer> path = new ArrayList<>();
        String current = end;
        while(previous.containsKey(current)){
            path.add(distance.get(current));
            current = String.valueOf(previous.get(current));
        }
        path.add(0);
        Collections.reverse(path);
        return path;
    }

    public static void main(String[] args) {
        graph = new HashMap<>();
        graph.put("Home",new HashMap<>(Map.of("Work",10, "Gym", 5, "Park", 7)));
        graph.put("Work",new HashMap<>(Map.of("Home",10, "Gym", 3, "Restaurant", 8)));
        graph.put("Gym",new HashMap<>(Map.of("Home",5,"Work",3, "Park", 6, "Restaurant", 4)));
        graph.put("Park",new HashMap<>(Map.of("Home",7, "Gym", 6, "Restaurant", 5)));
        graph.put("Restaurant",new HashMap<>(Map.of("Work",8, "Gym", 4, "Park", 5)));
        String start = "Gym";
        String end = "Park";
        List<Integer> shortestPath = shortestPath(graph,start,end);
        System.out.println("Shortest path from" + start+ " to "+end + shortestPath);
    }
}


//graph = {
//        'Home': {'Work': 10, 'Gym': 5, 'Park': 7},
//        'Work': {'Home': 10, 'Gym': 3, 'Restaurant': 8},
//        'Gym': {'Home': 5, 'Work': 3, 'Park': 6, 'Restaurant': 4},
//        'Park': {'Home': 7, 'Gym': 6, 'Restaurant': 5},
//        'Restaurant': {'Work': 8, 'Gym': 4, 'Park': 5}
//        }
//home- work - res->18
//gym-re-9
//park-rest->12
////
//h-p->12
//p-6
//r-p-9
//        start = 'Home'
//        end = 'Restaurant'
//        print("Shortest route from", start, "to",
