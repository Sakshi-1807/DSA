package interview;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class Solution {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(121,211,311,14,41,01);
        List<Integer> filteredNumbers = numbers.stream()
                .filter(n-> String.valueOf(n).startsWith("1")|| String.valueOf(n).startsWith("2"))
                .collect(Collectors.toList());

        Pattern pattern = Pattern.compile("^(1[1-9]|2.*)");
        List<Integer> filteredRNumbers = numbers.stream()
                .filter(n-> pattern.matcher(String.valueOf(n)).matches())
                .collect(Collectors.toList());
        System.out.println(filteredNumbers);
    }

}



