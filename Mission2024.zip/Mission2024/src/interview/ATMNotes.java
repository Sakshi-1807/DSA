package interview;
import java.util.*;
//Q Imagine you need to design a system for an ATM that dispenses money in denominations 100, 500 and 2000.
//
//
//        Create a Java class representing an ATM. Include methods to dispense money and track the available denominations.
//
//        Implement a method that takes an amount as input and calculates the minimum number of notes needed to dispense that amount using the available denominations.
//
//        Handle scenarios where the requested amount cannot be dispensed due to insufficient denominations.



public class ATMNotes {
    public static void main(String[] args) {
        int[] denominations = {2000, 500,100};
        int amount = 800;
        noteCount(amount, denominations);
//        System.out.println(count);

        HashMap<String, List<Integer>> map = new HashMap<>();

        map.put("mango", new ArrayList<Integer>(Arrays.asList(1, 2, 3, 4, 5)));
        System.out.println(map.toString());
//        List<Integer> test = map.get("mango");
        List<Integer> test1 = new ArrayList<>(map.get("mango"));
        test1.remove(0);
        System.out.println(map.toString());

    }

     public static void noteCount(int amount, int[] denominations) {
         int[] notesCount = new int[denominations.length];
         for (int i = 0; i < denominations.length; i++) {
             if (amount >= denominations[i]) {
                 notesCount[i] = amount / denominations[i];
                 amount = amount % denominations[i];
             }
         }
         for (int i = 0; i < denominations.length; i++) {
             if (notesCount[i] != 0) {
                 System.out.println(denominations[i] + ": " + notesCount[i]);
             }
         }
     }

}
