package interview;

import java.util.Arrays;
import java.util.PriorityQueue;

//list of coordinates are given, 1,0 2,0
//find k closest coordinates from horizom
public class ClosestKCoordinates {
    public static int[][] findKClosestCoordinates(int[][] coordinates, int k) {
        PriorityQueue<int[]> maxHeap = new PriorityQueue<>((a, b) ->
                Integer.compare(b[0] * b[0] + b[1] * b[1], a[0] * a[0] + a[1] * a[1]));
        for (int[] coordinate : coordinates) {
            int distance = coordinate[0] * coordinate[0] + coordinate[1] * coordinate[1];
            if (maxHeap.size() < k) {
                maxHeap.offer(coordinate);
            } else if (distance < (maxHeap.peek()[0] * maxHeap.peek()[0] + maxHeap.peek()[1] * maxHeap.peek()[1])) {
                maxHeap.poll();
                maxHeap.offer(coordinate);
            }
        }

        int[][] result = new int[k][2];
        for (int i = 0; i < k; i++) {
            result[i] = maxHeap.poll();
        }
        return result;
    }

    public static void main(String[] args) {
        int[][] coordinates = {
                {1, 0}, {2, 0}, {3, 0}
        };
        int[][] result = findKClosestCoordinates(coordinates, 2);
        for (int[] coordinate : result) {
            System.out.println(Arrays.toString(coordinate));
        }
    }
}



