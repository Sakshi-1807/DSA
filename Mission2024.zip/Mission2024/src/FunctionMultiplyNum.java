@FunctionalInterface
interface Multiplier{
    int multiply(int a, int b);
}
public class FunctionMultiplyNum {
    public static void main(String[] args) {
        Multiplier m = (a,b)-> a*b;
       int result =  m.multiply(2,5);
        System.out.println(result);
    }
}
