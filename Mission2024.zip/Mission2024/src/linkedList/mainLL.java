package linkedList;

import java.util.LinkedList;

public class mainLL {
    static Node head;
    static Node cur;

    static class Node {
        Node next;
        int data;

        Node(int data) {
            this.data = data;
            next = null;
        }
    }

    //   1- creation of linkedlist
    public static void createNode(int data) {
        if (head == null) {
            head = new Node(data);
            cur = head;
        } else {
            cur.next = new Node(data);
            cur = cur.next;
            cur.next = null;

        }
    }

    //   2- traversal
    public static void printNode() {
        Node n = head;
        while (n != null) {
            System.out.print(n.data + " , ");
            n = n.next;
        }
    }

    //    3- addition after
    //    4- deletion
    //5- Reverse the list
    public static Node reverseList(Node head) {
        // code here
        Node cur = head, prev = null, next;
        while (cur != null) {
            next = cur.next;
            cur.next = prev;
            prev = cur;
            cur = next;
        }
        head = prev;
        return head;
        // System.out.print(head.data);
    }

    //    6- get mid of ll
    public static int getMiddle() {
        Node slow = head, fast = head;
        while (fast.next != null && fast.next.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }
        return slow.data;

    }

    //7- detect a loop
    public static boolean detectLoop() {
        // Add code here
        Node slow = head, fast = head;
        while (fast.next != null && fast.next.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            if (slow == fast)
                return true;
        }
        return false;
    }

    //    8- keep 0,1,2 at a place
    static Node segregate() {
        Node h0 = new Node(-1);
        Node h1 = new Node(-1);
        Node h2 = new Node(-1);
        Node zero = h0;
        Node one = h1;
        Node two = h2;
        Node cur = head;
        Node temp;
        while (cur != null) {
            if (cur.data == 0) {
                temp = cur.next;
                zero.next = cur;
                zero = zero.next;
                cur = temp;
            } else if (cur.data == 1) {
                temp = cur.next;
                one.next = cur;
                one = one.next;
                cur = temp;
            } else if (cur.data == 2) {
                temp = cur.next;
                two.next = cur;
                two = two.next;
                cur = temp;
            }
        }
        zero.next = (h1.next != null) ? (h1.next) : (h2.next);
        one.next = h2.next;
        two.next = null;

        //updating the head of the list.
        head = h0.next;
        return head;
    }

    //    9- Delete the given node without having head info
    void deleteNode(Node del_node) {
        Node next = del_node.next;
        del_node.data = next.data;
        del_node.next = next.next;
        next.next = null;

    }

    //    10 - swap paiwise
    public static Node pairwiseSwap() {

        Node dummy = new Node(-1);
        dummy.next = head;
        Node point = dummy;

        while (point.next != null && point.next.next != null) {
            Node swap1 = point.next, swap2 = point.next.next;

            //lets swap the nodes
            swap1.next = swap2.next;
            swap2.next = swap1;

            //let's mov ethe pointer now
            point.next = swap2;
            point = swap1;
        }

        return dummy.next;
    }

    //    11- check if palindrome?
    boolean isPalindrome() {
        Node slow = head, fast = head;
        while (fast.next != null && fast.next.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }
            Node midHead = reverseList(slow.next);
            slow.next = null;
            Node h1 = head, h2 = midHead;
            while (h2 != null) {
                if (h1.data != h2.data) {
                    return false;
                }
                h1 = h1.next;
                h2 = h2.next;
            }
        return true;
    }

    public static void main(String[] args) {
        createNode(1);
        createNode(2);
        createNode(3);
        createNode(4);
        createNode(5);

        printNode();

//        reverseList();
//
//        System.out.println("---------- After reverse ---------");
//        printNode();

//        System.out.println(getMiddle() + " is the mid node");
//        segregate();
//        System.out.println("---------");
//        printNode();
        //******check for this function output , not showing correct result.
        pairwiseSwap();
        System.out.println("---------");
        printNode();
    }


}
