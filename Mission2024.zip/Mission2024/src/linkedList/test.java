//package InterviewPrepSheet.linkedList;
//
//public class BasicOperations {
//    static Node head = null;
//    static Node curr = null;
//
//    public static void addNode(int n) {
//        Node n1 = new Node(n);
//        if (head == null) {
//            head = n1;
//            curr = head;
//        } else {
//            curr.next = n1;
//            curr = curr.next;
//        }
//    }
//
//    public static void displayNodes() {
//        Node n = head;
//        while (n != null) {
//            System.out.println(n.value);
//            n = n.next;
//
//        }
//    }
//
//    public static void insertAfter(int value, int after) {
//        Node n = head;
//        while (n != null) {
//            if (n.value != after)
//                n = n.next;
//            else {
//                Node dummy = n.next;
//                n.next = new Node(value);
//                n.next.next = dummy;
//                break;
//            }
//        }
//    }
//
//    //    public static void reverseList() {
////        Node next = null;
////        Node previous = null;
////        Node current = head;
////
////        while (current != null) {
////            next = current.next;
////
////            current.next = previous;
////            previous = current;
////            current = next;
////        }
////        head = previous;
////    }
//    public static void reverseList() {
//        Node newHead =null;
//        while(head!=null){
//            Node next = head.next;
//            head.next =newHead;
//            newHead=head;
//            head = next;
//        }
//        head = newHead;
//    }
//
//
//    public static Boolean searchNode(int data) {
//        Node n = head;
//        while (n != null) {
//            if (n.value == data)
//                return true;
//            n = n.next;
//        }
//        return false;
//    }
//    private static void insertLast(int value) {
//        Node newNode = new Node(value);
//        if(head ==null){
//            head = newNode;
//            newNode.next=null;
//            curr=head;
//        }
//        else{
//            while(curr.next!=null){
//                curr = curr.next;
//            }
//            curr.next = newNode;
//            curr = curr.next;
//            curr.next=null;
//        }
//
//    }
//    public static Node removeNthFromEnd(Node head, int n) {
//        Node temp = head;
//        int count = 0;
//        if (head == null) {
//            return head;
//        }
//        //count no of elements
//        while (temp != null) {
//            temp = temp.next;
//            count++;
//        }
//        if (count < n) {
//            return head;
//        }
//        temp = head;
//        for (int i = 1; i < count - n + 1; i++) {
//            temp = temp.next;
//        }
//        if (temp.next!=null && temp.next.next != null) {
//            temp.next = temp.next.next;
//        } else {
//            temp.next = null;
//        }
//
//        return head;
//    }
//
//    public static void main(String[] args) {
//        addNode(10);
//        addNode(20);
//        addNode(30);
//        addNode(40);
//        displayNodes();
//        System.out.println("-------------------------");
//        removeNthFromEnd(head,1);
//        System.out.println("------after removal of last-----"+2+"--------------");
//        displayNodes();
//        System.out.println("--------------------");
//        insertAfter(35, 30);
//        displayNodes();
//        System.out.println(searchNode(65));
//        insertLast(50);
//        reverseList();
//        System.out.println("-------------------------");
//        removeNthFromEnd(head,1);
//        displayNodes();
//
//
//    }
//
//
//}
