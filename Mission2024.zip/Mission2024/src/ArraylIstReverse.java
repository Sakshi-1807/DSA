import java.util.*;
import java.util.stream.Collectors;

public class ArraylIstReverse {
    public static void main(String[] args) {
        List<Integer> list = new ArrayList<>();
        list.add(3);
        list.add(8);
        list.add(7);
        list.add(80);

        List<Integer> reversedList =  list.stream().sorted((a,b)->b.compareTo(a)).collect(Collectors.toList());
        reversedList.forEach(System.out::println);

    }

}
