package vardaan;

public class EvenSumOddProd {


    public static void main(String[] args) {
        int num = 43782;
        int sum=0, prod =1;
        int digit;
        while(num!=0){
            digit = num%10;// to find the last digit
            if(digit %2 == 0){
                sum += digit;// sum = sum + digit;
            }else{
                prod*= digit;
            }
            num = num/10;// to find the number other than the last digit
        }
        System.out.println("Sum of even :" +sum);
        System.out.println("prod : " + prod);
    }
}
