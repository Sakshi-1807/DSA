package vardaan;

public class ArmstrongNum {
    public static void main(String[] args) {
        int num = 153;
        int number, remainder, result = 0, count = 0;
        number = num;
        //to find the no of digits
        while (number != 0) {
            count++;
            number /= 10;
        }
        number = num;
        //making power of the digits
        while (number != 0) {
            remainder = number % 10;
            result += Math.pow(remainder, count);
            number /= 10;
        }
        //compare if result eq given no
//        if (result == num) {
//            System.out.println("yes");
//        } else {
//            System.out.println("no");
//        }

        char ch;
        int x = 65;
        do {
            ch = (char) x;
            System.out.print(ch + " ");
            x++;
        }while (x < 69) ;


        String a="40";
        String b="60";
        int p= Integer.parseInt(a); int q= Integer.parseInt(b);
        System.out.print(p*q);


        System.out.println("The languages are \n\nJava\tCobol\nPython");
    }
}
