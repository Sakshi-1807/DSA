import java.util.*;

public class Student {
    private int id;
    private String name;
    private int age;

    public Student(int id, String name, int age) throws NameNullException {
        if (name == null) {
            throw new NameNullException("Name cannot be null");
        }
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) throws NameNullException {
        if (name == null) {
            throw new NameNullException("Name cannot be null");
        }
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public static void main(String[] args) throws NameNullException {
        List<Student> studentList = Arrays.asList(new Student(001, "Sakshi", 28), new Student(002, "Saiyam", 28),
                new Student(003, "Amit", 43), new Student(004, null, 42));

        studentList.stream().filter(student -> student.getAge() < 80).
                sorted(Comparator.comparing(Student::getName).reversed()).
                forEach(student -> System.out.println("ID - " + student.getId() + ", Name: " + student.getName() + ", Age: " + student.getAge()));

    }
}
