import java.util.Stack;

public class BracketBalance {
    public static void main(String[] args) {
        String s = "[]({}";
        boolean ans = checkIfBalanced(s);
        System.out.println(ans);
    }

    private static boolean checkIfBalanced(String s) {
        Stack<Character> stack = new Stack<>();
        for(char c : s.toCharArray()){
            if(c=='(' ||c=='{' || c=='['){
                stack.push(c);
            }else if (!stack.isEmpty() && ((c==')' && stack.peek()=='(' ) ||
                    (c=='}' && stack.peek()=='{')
                    || c==']' && stack.peek()=='['))
                stack.pop();
            else
                return false;
        }
        return stack.isEmpty();
    }
}
