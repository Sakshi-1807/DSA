package array;

public class mainArray {
    public static void main(String[] args) {
        int[] arr = { 5,5,5,8};
        a2_largest a2 = new a2_largest();
        a2.secondLargest_bruteforce(arr);
        a2.secondLargest_optimal(arr);
    }
}
