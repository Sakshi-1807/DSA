package array;

import java.util.*;

public class a1_twoSum {
    void find_bruteforce(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[i] + arr[j] == target) {
                    System.out.println("element are : " + arr[i] + " , " + arr[j]);
                }
            }
        }
    }

    void find(int[] arr, int target) {
        Map<Integer, Integer> map = new HashMap<>();
        for (int i = 0; i < arr.length; i++) {
            int val = target - arr[i];
            if(map.containsKey(val)){
               int index = map.get(val);
                System.out.println("Indexes are : " + index+" , "+i);
            }
            else{
                map.put(arr[i],i);
            }
        }
    }
}
