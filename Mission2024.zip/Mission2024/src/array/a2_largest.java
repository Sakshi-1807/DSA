package array;

public class a2_largest {
    int largest(int[] arr) {
        //either I can sort the array and print last element but time - O(n log n) so better way is to traverse and compare which is O(n)
        int largest = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > largest)
                largest = arr[i];
        }
        return largest;
    }

    void secondLargest_bruteforce(int[] arr) {
        int largest = largest(arr);
        int secondL = -1;
        for (int i = 0; i < arr.length; i++) {
            if(arr[i] <largest && arr[i] > secondL){
                secondL = arr[i];
            }
        }
        System.out.println(secondL);
    }

    void secondLargest_optimal(int[] arr) {
        int largest = arr[0];
        int secondL = Integer.MIN_VALUE;
        for (int i = 0; i < arr.length; i++) {
            if(arr[i] > largest){
                secondL = largest;
                largest = arr[i];
            }
            else if(arr[i]<largest && arr[i]>secondL){
                secondL = arr[i];
            }
        }
        System.out.println(secondL);
    }
}
