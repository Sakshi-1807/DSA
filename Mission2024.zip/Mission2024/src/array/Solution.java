package array;
import java.util.Arrays;

public class Solution {
        public static int[] findPair(int[] nums, int target) {
            // Sort the array
            Arrays.sort(nums);

            // Find the right boundary using binary search
            int rightBound = findRightBoundary(nums, target);

            // Initialize two pointers
            int left = 0;
            int right = rightBound;

            // While loop to find the pair
            while (left < right) {
                int sum = nums[left] + nums[right];

                // If the sum is equal to the target, return the pair
                if (sum == target) {
                    return new int[]{nums[left], nums[right]};
                }

                // If the sum is less than the target, move the left pointer to the right
                if (sum < target) {
                    left++;
                } else { // If the sum is greater than the target, move the right pointer to the left
                    right--;
                }
            }

            // Return null if no pair is found
            return null;
        }

        private static int findRightBoundary(int[] nums, int target) {
            int left = 0;
            int right = nums.length - 1;
            while (left <= right) {
                int mid = left + (right - left) / 2;
                if (nums[mid] <= target) {
                    left = mid + 1;
                } else {
                    right = mid - 1;
                }
            }
            return right; // right will be the last index where nums[right] <= target
        }

        public static void main(String[] args) {
            int[] nums = {2,2,4,3,6,1,7,11};
            int target = 8;

            int[] result = findPair(nums, target);
            if (result != null) {
                System.out.println("Pair found: " + result[0] + ", " + result[1]);
            } else {
                System.out.println("No pair found.");
            }
        }
    }


